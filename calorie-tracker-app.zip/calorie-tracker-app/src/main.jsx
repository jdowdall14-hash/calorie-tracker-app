import React, { useEffect, useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { addDoc, collection, deleteDoc, doc, getDocs, orderBy, query, serverTimestamp, setDoc } from 'firebase/firestore';
import { CalendarDays, Flame, LogOut, Plus, Scale, Trash2, Utensils, Wine } from 'lucide-react';
import { auth, db, provider, signInWithPopup, signOut, onAuthStateChanged } from './firebase';
import './styles.css';

const defaultTarget = 2000;
const startWeightLb = 15 * 14 + 7;
const goalWeightLb = 14 * 14 + 7;

const quickFoods = [
  { name: 'Protein yoghurt + banana', calories: 300, type: 'Breakfast' },
  { name: 'Bacon sandwich', calories: 420, type: 'Breakfast' },
  { name: 'Meal deal chicken wrap', calories: 520, type: 'Lunch' },
  { name: 'Ham salad sandwich', calories: 430, type: 'Lunch' },
  { name: 'Chicken wrap packed lunch', calories: 450, type: 'Lunch' },
  { name: 'Homemade chilli + rice', calories: 650, type: 'Dinner' },
  { name: 'Spag bol', calories: 700, type: 'Dinner' },
  { name: 'McDonald’s Big Mac meal', calories: 1080, type: 'Fast food' },
  { name: 'Pint cider', calories: 240, type: 'Alcohol' },
  { name: 'Vodka Diet Coke', calories: 70, type: 'Alcohol' },
];

function formatStonePounds(lb) {
  const stone = Math.floor(lb / 14);
  const pounds = Math.round(lb % 14);
  return `${stone}st ${pounds}lb`;
}

function todayKey() {
  return new Date().toISOString().slice(0, 10);
}

function Login() {
  return (
    <main className="login-screen">
      <section className="login-card">
        <div className="badge">Lose A Stone</div>
        <h1>Simple calorie tracking without the gym-bro nonsense.</h1>
        <p>Log meals, drinks, meal deals and weekly weigh-ins. Built for normal food, packed lunches and nights out.</p>
        <button onClick={() => signInWithPopup(auth, provider)}>Sign in with Google</button>
      </section>
    </main>
  );
}

function App() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => onAuthStateChanged(auth, (u) => { setUser(u); setLoading(false); }), []);

  if (loading) return <div className="loading">Loading...</div>;
  if (!user) return <Login />;
  return <Tracker user={user} />;
}

function Tracker({ user }) {
  const [entries, setEntries] = useState([]);
  const [weights, setWeights] = useState([]);
  const [target, setTarget] = useState(defaultTarget);
  const [selectedDate, setSelectedDate] = useState(todayKey());
  const [customName, setCustomName] = useState('');
  const [customCalories, setCustomCalories] = useState('');
  const [customType, setCustomType] = useState('Food');
  const [weightInput, setWeightInput] = useState('');

  const entriesRef = collection(db, 'users', user.uid, 'entries');
  const weightsRef = collection(db, 'users', user.uid, 'weights');

  async function loadData() {
    const entrySnap = await getDocs(query(entriesRef, orderBy('date', 'desc')));
    setEntries(entrySnap.docs.map(d => ({ id: d.id, ...d.data() })));
    const weightSnap = await getDocs(query(weightsRef, orderBy('date', 'desc')));
    setWeights(weightSnap.docs.map(d => ({ id: d.id, ...d.data() })));
  }

  useEffect(() => { loadData(); }, []);

  const todayEntries = entries.filter(e => e.date === selectedDate);
  const total = todayEntries.reduce((sum, e) => sum + Number(e.calories || 0), 0);
  const remaining = target - total;

  const latestWeight = weights[0]?.weightLb || startWeightLb;
  const lost = Math.max(0, startWeightLb - latestWeight);
  const goalLeft = Math.max(0, latestWeight - goalWeightLb);
  const progress = Math.min(100, Math.round((lost / 14) * 100));

  async function addEntry(item) {
    await addDoc(entriesRef, {
      ...item,
      calories: Number(item.calories),
      date: selectedDate,
      createdAt: serverTimestamp(),
    });
    await loadData();
  }

  async function addCustomEntry(e) {
    e.preventDefault();
    if (!customName || !customCalories) return;
    await addEntry({ name: customName, calories: Number(customCalories), type: customType });
    setCustomName('');
    setCustomCalories('');
  }

  async function removeEntry(id) {
    await deleteDoc(doc(db, 'users', user.uid, 'entries', id));
    await loadData();
  }

  async function saveWeight(e) {
    e.preventDefault();
    const value = Number(weightInput);
    if (!value) return;
    await addDoc(weightsRef, { weightLb: value, date: todayKey(), createdAt: serverTimestamp() });
    setWeightInput('');
    await loadData();
  }

  async function saveTarget(newTarget) {
    const value = Number(newTarget);
    setTarget(value);
    await setDoc(doc(db, 'users', user.uid), { calorieTarget: value }, { merge: true });
  }

  return (
    <main className="app-shell">
      <header className="topbar">
        <div>
          <p className="eyebrow">Lose A Stone Tracker</p>
          <h1>Today’s calories</h1>
        </div>
        <button className="ghost" onClick={() => signOut(auth)}><LogOut size={16} /> Sign out</button>
      </header>

      <section className="dashboard">
        <div className="card hero-card">
          <div className="row between">
            <div><p className="label">Remaining today</p><h2 className={remaining < 0 ? 'danger' : ''}>{remaining} kcal</h2></div>
            <Flame size={34} />
          </div>
          <div className="meter"><span style={{ width: `${Math.min(100, (total / target) * 100)}%` }} /></div>
          <p>{total} eaten from a {target} target.</p>
          <label className="field small">Daily target
            <input type="number" value={target} onChange={e => saveTarget(e.target.value)} />
          </label>
        </div>

        <div className="card">
          <div className="row"><Scale /> <h3>Weight goal</h3></div>
          <p>Start: {formatStonePounds(startWeightLb)}</p>
          <p>Latest: <strong>{formatStonePounds(latestWeight)}</strong></p>
          <p>Goal: {formatStonePounds(goalWeightLb)}</p>
          <div className="meter"><span style={{ width: `${progress}%` }} /></div>
          <p>{goalLeft} lb left to lose one stone.</p>
          <form onSubmit={saveWeight} className="inline-form">
            <input placeholder="Weight in lb e.g. 217" value={weightInput} onChange={e => setWeightInput(e.target.value)} />
            <button>Save</button>
          </form>
        </div>
      </section>

      <section className="grid">
        <div className="card">
          <div className="row"><CalendarDays /> <h3>Pick day</h3></div>
          <input type="date" value={selectedDate} onChange={e => setSelectedDate(e.target.value)} />
        </div>

        <div className="card">
          <div className="row"><Plus /> <h3>Add custom</h3></div>
          <form onSubmit={addCustomEntry} className="stack">
            <input placeholder="Food or drink" value={customName} onChange={e => setCustomName(e.target.value)} />
            <input type="number" placeholder="Calories" value={customCalories} onChange={e => setCustomCalories(e.target.value)} />
            <select value={customType} onChange={e => setCustomType(e.target.value)}>
              <option>Food</option><option>Breakfast</option><option>Lunch</option><option>Dinner</option><option>Snack</option><option>Alcohol</option><option>Fast food</option>
            </select>
            <button>Add item</button>
          </form>
        </div>
      </section>

      <section className="card">
        <div className="row"><Utensils /> <h3>Quick add normal UK food</h3></div>
        <div className="quick-grid">
          {quickFoods.map(item => (
            <button key={item.name} className="quick" onClick={() => addEntry(item)}>
              <strong>{item.name}</strong><span>{item.calories} kcal · {item.type}</span>
            </button>
          ))}
        </div>
      </section>

      <section className="card">
        <div className="row"><Wine /> <h3>{selectedDate} log</h3></div>
        {todayEntries.length === 0 ? <p>No items logged yet.</p> : (
          <div className="entry-list">
            {todayEntries.map(entry => (
              <div className="entry" key={entry.id}>
                <div><strong>{entry.name}</strong><span>{entry.type}</span></div>
                <div className="row"><b>{entry.calories}</b><button className="icon" onClick={() => removeEntry(entry.id)}><Trash2 size={16} /></button></div>
              </div>
            ))}
          </div>
        )}
      </section>
    </main>
  );
}

createRoot(document.getElementById('root')).render(<App />);
