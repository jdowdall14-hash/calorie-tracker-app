# Lose A Stone Tracker

A separate Firebase + React calorie tracker app. This is designed to live away from the piercing app so both can have their own Firebase project and hosting URL.

## What it does

- Google login
- Daily calorie target
- Quick add common meals/drinks
- Custom food/drink logging
- Weight tracking in stone/pounds via lb input
- Firebase Firestore per-user storage
- Firebase Hosting deployment

## Set up locally

```bash
npm install
cp .env.example .env
npm run dev
```

Fill `.env` with the Firebase web app config from your new Firebase project.

## Firebase setup

1. Go to Firebase Console.
2. Add project, for example `lose-a-stone-tracker`.
3. Add a Web App.
4. Copy the Firebase config values into `.env`.
5. Enable Authentication > Sign-in method > Google.
6. Enable Firestore Database.
7. Add these Firestore rules for owner-only data:

```js
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /users/{userId} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
      match /{document=**} {
        allow read, write: if request.auth != null && request.auth.uid == userId;
      }
    }
  }
}
```

## Deploy as a second hosting app

Install Firebase CLI if you have not already:

```bash
npm install -g firebase-tools
firebase login
```

Then in this app folder:

```bash
firebase use --add
```

Pick the new Firebase project, not the piercing app project.

Then deploy:

```bash
npm run firebase:deploy
```

Your new hosting link will be shown after deploy, usually like:

```text
https://your-new-project-id.web.app
```

## Important

Keep this in a completely separate folder from the piercing app:

```text
projects/
  piercing-app/
  calorie-tracker-app/
```

Do not run `firebase init` inside the piercing app folder for this tracker.
